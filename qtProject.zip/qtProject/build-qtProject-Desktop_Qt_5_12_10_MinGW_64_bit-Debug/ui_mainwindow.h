/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSave;
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionCreateBarGraphic;
    QAction *actionAddActivity;
    QAction *actionRemoveActivity;
    QAction *actionAddStudent;
    QAction *actionRemoveStudent;
    QAction *actionCalculate_Average;
    QAction *actionSave_Graphic;
    QAction *actionPrint;
    QAction *actionCreated_Binary_Tree;
    QAction *actionUndo;
    QAction *actionRedo;
    QAction *actionInformation;
    QAction *actionLogin;
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QTableView *tableView;
    QGridLayout *gridLayout_3;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuHerramientas;
    QMenu *menuEdit;
    QMenu *menuCuenta;
    QStatusBar *statusbar;
    QToolBar *toolBar;
    QToolBar *toolBar_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1197, 817);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMaximumSize(QSize(16777215, 16777215));
        MainWindow->setBaseSize(QSize(1320, 720));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/LOGO.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setLayoutDirection(Qt::LeftToRight);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QString::fromUtf8("actionSave"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/diskette.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon1);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QString::fromUtf8("actionNew"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/table.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon2);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon3);
        actionCreateBarGraphic = new QAction(MainWindow);
        actionCreateBarGraphic->setObjectName(QString::fromUtf8("actionCreateBarGraphic"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/images/incrementar.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCreateBarGraphic->setIcon(icon4);
        actionAddActivity = new QAction(MainWindow);
        actionAddActivity->setObjectName(QString::fromUtf8("actionAddActivity"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/images/add.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddActivity->setIcon(icon5);
        actionRemoveActivity = new QAction(MainWindow);
        actionRemoveActivity->setObjectName(QString::fromUtf8("actionRemoveActivity"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/images/delete.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemoveActivity->setIcon(icon6);
        actionAddStudent = new QAction(MainWindow);
        actionAddStudent->setObjectName(QString::fromUtf8("actionAddStudent"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/images/add-user.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAddStudent->setIcon(icon7);
        actionRemoveStudent = new QAction(MainWindow);
        actionRemoveStudent->setObjectName(QString::fromUtf8("actionRemoveStudent"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/images/remove-user.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRemoveStudent->setIcon(icon8);
        actionCalculate_Average = new QAction(MainWindow);
        actionCalculate_Average->setObjectName(QString::fromUtf8("actionCalculate_Average"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/images/score.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCalculate_Average->setIcon(icon9);
        actionSave_Graphic = new QAction(MainWindow);
        actionSave_Graphic->setObjectName(QString::fromUtf8("actionSave_Graphic"));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/images/png.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_Graphic->setIcon(icon10);
        actionPrint = new QAction(MainWindow);
        actionPrint->setObjectName(QString::fromUtf8("actionPrint"));
        QIcon icon11;
        icon11.addFile(QString::fromUtf8(":/images/printer.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPrint->setIcon(icon11);
        actionCreated_Binary_Tree = new QAction(MainWindow);
        actionCreated_Binary_Tree->setObjectName(QString::fromUtf8("actionCreated_Binary_Tree"));
        QIcon icon12;
        icon12.addFile(QString::fromUtf8(":/images/savannah.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCreated_Binary_Tree->setIcon(icon12);
        actionUndo = new QAction(MainWindow);
        actionUndo->setObjectName(QString::fromUtf8("actionUndo"));
        QIcon icon13;
        icon13.addFile(QString::fromUtf8(":/images/undo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionUndo->setIcon(icon13);
        actionRedo = new QAction(MainWindow);
        actionRedo->setObjectName(QString::fromUtf8("actionRedo"));
        QIcon icon14;
        icon14.addFile(QString::fromUtf8(":/images/redo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRedo->setIcon(icon14);
        actionInformation = new QAction(MainWindow);
        actionInformation->setObjectName(QString::fromUtf8("actionInformation"));
        QIcon icon15;
        icon15.addFile(QString::fromUtf8(":/images/info.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionInformation->setIcon(icon15);
        actionLogin = new QAction(MainWindow);
        actionLogin->setObjectName(QString::fromUtf8("actionLogin"));
        QIcon icon16;
        icon16.addFile(QString::fromUtf8(":/images/login.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionLogin->setIcon(icon16);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tableView->sizePolicy().hasHeightForWidth());
        tableView->setSizePolicy(sizePolicy1);
        tableView->horizontalHeader()->setVisible(false);
        tableView->verticalHeader()->setVisible(false);

        gridLayout->addWidget(tableView, 0, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));

        gridLayout_2->addLayout(gridLayout_3, 1, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1197, 21));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuHerramientas = new QMenu(menubar);
        menuHerramientas->setObjectName(QString::fromUtf8("menuHerramientas"));
        menuEdit = new QMenu(menubar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        menuCuenta = new QMenu(menubar);
        menuCuenta->setObjectName(QString::fromUtf8("menuCuenta"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);
        toolBar_2 = new QToolBar(MainWindow);
        toolBar_2->setObjectName(QString::fromUtf8("toolBar_2"));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar_2);
        MainWindow->insertToolBarBreak(toolBar_2);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuHerramientas->menuAction());
        menubar->addAction(menuEdit->menuAction());
        menubar->addAction(menuCuenta->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addSeparator();
        menuFile->addAction(actionPrint);
        menuHerramientas->addAction(actionCreateBarGraphic);
        menuHerramientas->addAction(actionSave_Graphic);
        menuHerramientas->addSeparator();
        menuHerramientas->addAction(actionAddActivity);
        menuHerramientas->addAction(actionRemoveActivity);
        menuHerramientas->addSeparator();
        menuHerramientas->addAction(actionAddStudent);
        menuHerramientas->addAction(actionRemoveStudent);
        menuHerramientas->addAction(actionCalculate_Average);
        menuHerramientas->addSeparator();
        menuHerramientas->addAction(actionCreated_Binary_Tree);
        menuHerramientas->addSeparator();
        menuHerramientas->addAction(actionInformation);
        menuEdit->addAction(actionUndo);
        menuEdit->addAction(actionRedo);
        menuCuenta->addAction(actionLogin);
        toolBar->addAction(actionNew);
        toolBar->addAction(actionOpen);
        toolBar->addAction(actionSave);
        toolBar->addAction(actionPrint);
        toolBar->addAction(actionUndo);
        toolBar->addAction(actionRedo);
        toolBar->addAction(actionInformation);
        toolBar_2->addAction(actionAddActivity);
        toolBar_2->addAction(actionRemoveActivity);
        toolBar_2->addAction(actionAddStudent);
        toolBar_2->addAction(actionRemoveStudent);
        toolBar_2->addAction(actionCalculate_Average);
        toolBar_2->addAction(actionCreateBarGraphic);
        toolBar_2->addAction(actionSave_Graphic);
        toolBar_2->addAction(actionCreated_Binary_Tree);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Qt Project", nullptr));
        actionSave->setText(QApplication::translate("MainWindow", "Guardar", nullptr));
        actionNew->setText(QApplication::translate("MainWindow", "Nuevo Tabla", nullptr));
        actionOpen->setText(QApplication::translate("MainWindow", "Abrir", nullptr));
        actionCreateBarGraphic->setText(QApplication::translate("MainWindow", "Generar Gr\303\241fica", nullptr));
        actionAddActivity->setText(QApplication::translate("MainWindow", "Agregar Actividad", nullptr));
        actionRemoveActivity->setText(QApplication::translate("MainWindow", "Quitar Actividad", nullptr));
        actionAddStudent->setText(QApplication::translate("MainWindow", "Agregar Estudiante", nullptr));
        actionRemoveStudent->setText(QApplication::translate("MainWindow", "Quitar Estudiante", nullptr));
        actionCalculate_Average->setText(QApplication::translate("MainWindow", "Calcular Promedio", nullptr));
        actionSave_Graphic->setText(QApplication::translate("MainWindow", "Guardar Gr\303\241fica", nullptr));
        actionPrint->setText(QApplication::translate("MainWindow", "Imprimir", nullptr));
        actionCreated_Binary_Tree->setText(QApplication::translate("MainWindow", "Generar Arbol Binario", nullptr));
        actionUndo->setText(QApplication::translate("MainWindow", "Deshacer", nullptr));
        actionRedo->setText(QApplication::translate("MainWindow", "Rehacer", nullptr));
        actionInformation->setText(QApplication::translate("MainWindow", "Informaci\303\263n", nullptr));
        actionLogin->setText(QApplication::translate("MainWindow", "Ingresar", nullptr));
        menuFile->setTitle(QApplication::translate("MainWindow", "Archivo", nullptr));
        menuHerramientas->setTitle(QApplication::translate("MainWindow", "Herramientas", nullptr));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Editar", nullptr));
        menuCuenta->setTitle(QApplication::translate("MainWindow", "Cuenta", nullptr));
        toolBar->setWindowTitle(QApplication::translate("MainWindow", "toolBar", nullptr));
        toolBar_2->setWindowTitle(QApplication::translate("MainWindow", "toolBar_2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
