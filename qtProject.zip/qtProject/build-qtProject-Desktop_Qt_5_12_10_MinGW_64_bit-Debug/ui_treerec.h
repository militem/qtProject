/********************************************************************************
** Form generated from reading UI file 'treerec.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TREEREC_H
#define UI_TREEREC_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TreeRec
{
public:
    QGridLayout *gridLayout;
    QDialogButtonBox *buttonBox;
    QGroupBox *groupBox;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *txt_NumStd;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *txt_Date;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *txt_Title;
    QWidget *widget3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *txt_NumAct;
    QWidget *widget4;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_6;
    QLineEdit *txt_Time;

    void setupUi(QDialog *TreeRec)
    {
        if (TreeRec->objectName().isEmpty())
            TreeRec->setObjectName(QString::fromUtf8("TreeRec"));
        TreeRec->resize(400, 221);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/info.png"), QSize(), QIcon::Normal, QIcon::Off);
        TreeRec->setWindowIcon(icon);
        gridLayout = new QGridLayout(TreeRec);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        buttonBox = new QDialogButtonBox(TreeRec);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 2, 1, 1, 1);

        groupBox = new QGroupBox(TreeRec);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        widget = new QWidget(groupBox);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 140, 181, 22));
        horizontalLayout_4 = new QHBoxLayout(widget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        txt_NumStd = new QLineEdit(widget);
        txt_NumStd->setObjectName(QString::fromUtf8("txt_NumStd"));
        txt_NumStd->setEnabled(false);

        horizontalLayout_4->addWidget(txt_NumStd);

        widget1 = new QWidget(groupBox);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(10, 50, 231, 22));
        horizontalLayout_2 = new QHBoxLayout(widget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget1);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        txt_Date = new QLineEdit(widget1);
        txt_Date->setObjectName(QString::fromUtf8("txt_Date"));
        txt_Date->setEnabled(false);

        horizontalLayout_2->addWidget(txt_Date);

        widget2 = new QWidget(groupBox);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        widget2->setGeometry(QRect(10, 20, 361, 22));
        horizontalLayout = new QHBoxLayout(widget2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(widget2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        txt_Title = new QLineEdit(widget2);
        txt_Title->setObjectName(QString::fromUtf8("txt_Title"));

        horizontalLayout->addWidget(txt_Title);

        widget3 = new QWidget(groupBox);
        widget3->setObjectName(QString::fromUtf8("widget3"));
        widget3->setGeometry(QRect(10, 110, 153, 22));
        horizontalLayout_3 = new QHBoxLayout(widget3);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        txt_NumAct = new QLineEdit(widget3);
        txt_NumAct->setObjectName(QString::fromUtf8("txt_NumAct"));
        txt_NumAct->setEnabled(false);

        horizontalLayout_3->addWidget(txt_NumAct);

        widget4 = new QWidget(groupBox);
        widget4->setObjectName(QString::fromUtf8("widget4"));
        widget4->setGeometry(QRect(10, 80, 101, 22));
        horizontalLayout_6 = new QHBoxLayout(widget4);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(widget4);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_6->addWidget(label_6);

        txt_Time = new QLineEdit(widget4);
        txt_Time->setObjectName(QString::fromUtf8("txt_Time"));
        txt_Time->setEnabled(false);

        horizontalLayout_6->addWidget(txt_Time);


        gridLayout->addWidget(groupBox, 0, 0, 1, 2);


        retranslateUi(TreeRec);
        QObject::connect(buttonBox, SIGNAL(accepted()), TreeRec, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), TreeRec, SLOT(reject()));

        QMetaObject::connectSlotsByName(TreeRec);
    } // setupUi

    void retranslateUi(QDialog *TreeRec)
    {
        TreeRec->setWindowTitle(QApplication::translate("TreeRec", "Informaci\303\263n", nullptr));
        groupBox->setTitle(QApplication::translate("TreeRec", "Informaci\303\263n", nullptr));
        label_4->setText(QApplication::translate("TreeRec", "N\303\272mero de Estudiantes:", nullptr));
        label->setText(QApplication::translate("TreeRec", "Fecha:", nullptr));
        label_2->setText(QApplication::translate("TreeRec", "T\303\255tulo:", nullptr));
        label_3->setText(QApplication::translate("TreeRec", "N\303\272mero de Notas:", nullptr));
        label_6->setText(QApplication::translate("TreeRec", "Hora:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TreeRec: public Ui_TreeRec {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TREEREC_H
