/********************************************************************************
** Form generated from reading UI file 'newtabledialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWTABLEDIALOG_H
#define UI_NEWTABLEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NewTableDialog
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QSpinBox *rows;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QSpinBox *cols;

    void setupUi(QDialog *NewTableDialog)
    {
        if (NewTableDialog->objectName().isEmpty())
            NewTableDialog->setObjectName(QString::fromUtf8("NewTableDialog"));
        NewTableDialog->resize(292, 178);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/table.png"), QSize(), QIcon::Normal, QIcon::Off);
        NewTableDialog->setWindowIcon(icon);
        buttonBox = new QDialogButtonBox(NewTableDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(100, 100, 91, 61));
        buttonBox->setOrientation(Qt::Vertical);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget = new QWidget(NewTableDialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 10, 211, 81));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        rows = new QSpinBox(layoutWidget);
        rows->setObjectName(QString::fromUtf8("rows"));

        horizontalLayout->addWidget(rows);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        cols = new QSpinBox(layoutWidget);
        cols->setObjectName(QString::fromUtf8("cols"));

        horizontalLayout_2->addWidget(cols);


        verticalLayout_2->addLayout(horizontalLayout_2);


        retranslateUi(NewTableDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), NewTableDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), NewTableDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(NewTableDialog);
    } // setupUi

    void retranslateUi(QDialog *NewTableDialog)
    {
        NewTableDialog->setWindowTitle(QApplication::translate("NewTableDialog", "Nueva Tabla", nullptr));
        label->setText(QApplication::translate("NewTableDialog", "N\303\272mero de Estudiantes", nullptr));
        label_2->setText(QApplication::translate("NewTableDialog", "N\303\272mero de Notas", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NewTableDialog: public Ui_NewTableDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWTABLEDIALOG_H
