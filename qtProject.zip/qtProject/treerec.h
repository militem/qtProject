#ifndef TREEREC_H
#define TREEREC_H

#include <QDialog>

namespace Ui {
class TreeRec;
}

class TreeRec : public QDialog
{
    Q_OBJECT

public:
    explicit TreeRec(QWidget *parent = nullptr);
    ~TreeRec();
    void setData(QString, int, int);
    QString getTitle();

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::TreeRec *ui;
    QString title;
    int num_Act, num_Std;
};

#endif // TREEREC_H
