#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QTranslator traduction;
    QStringList idioms;
    idioms<<"Español"<<"Ingles"<<"Frances";
    QString languages = QInputDialog::getItem(NULL, "Idioma", "Seleccione un idioma", idioms);
    if(languages=="Ingles"){
        traduction.load(":/ingles.qm");
    }else{
       if(languages=="Frances"){
           traduction.load(":/frances.qm");
       }
    }
    a.installTranslator(&traduction);
    MainWindow w;
    w.show();
    return a.exec();
}
