<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR" sourcelanguage="es_419">
<context>
    <name>Login</name>
    <message>
        <location filename="login.ui" line="14"/>
        <source>Ingresar</source>
        <translation>Entrée</translation>
    </message>
    <message>
        <location filename="login.ui" line="46"/>
        <source>Contraseña</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <location filename="login.ui" line="77"/>
        <source>Correo Institucional</source>
        <translation>Courrier institutionnel</translation>
    </message>
    <message>
        <location filename="login.ui" line="98"/>
        <source>Iniciar Sesión</source>
        <translation>Commencer la session</translation>
    </message>
    <message>
        <location filename="login.cpp" line="24"/>
        <location filename="login.cpp" line="28"/>
        <source>Inicio de sesion</source>
        <translation>Login</translation>
    </message>
    <message>
        <location filename="login.cpp" line="24"/>
        <source>Se ha iniciado correctamente sesion</source>
        <translation>La session a bien démarré</translation>
    </message>
    <message>
        <location filename="login.cpp" line="28"/>
        <source>Usuario y contraseña invalido</source>
        <translation>Nom d&apos;utilisateur et mot de passe invalides</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="32"/>
        <source>Qt Project</source>
        <translation>Qt Project</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>Archivo</source>
        <translation>Archiver</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="89"/>
        <source>Herramientas</source>
        <translation>Outils</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="107"/>
        <source>Editar</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="114"/>
        <source>Cuenta</source>
        <translation>Compte</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="126"/>
        <source>toolBar</source>
        <translation>toolBar</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="144"/>
        <source>toolBar_2</source>
        <translation>toolBar_2</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="167"/>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="94"/>
        <source>Guardar</source>
        <translation>Sauvegarder</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="176"/>
        <source>Nuevo Tabla</source>
        <translation>Nouvelle table</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="185"/>
        <location filename="mainwindow.cpp" line="262"/>
        <source>Abrir</source>
        <translation>Ouvert</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="194"/>
        <source>Generar Gráfica</source>
        <translation>Générer un graphique</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="203"/>
        <source>Agregar Actividad</source>
        <translation>Générer une activité</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>Quitar Actividad</source>
        <translation>Supprimer l&apos;activité</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="221"/>
        <source>Agregar Estudiante</source>
        <translation>Ajouter un étudiant</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="230"/>
        <source>Quitar Estudiante</source>
        <translation>Supprimer l&apos;élève</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="239"/>
        <source>Calcular Promedio</source>
        <translation>Calculer la moyenne</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="248"/>
        <source>Guardar Gráfica</source>
        <translation>Enregistrer le graphique</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="257"/>
        <source>Imprimir</source>
        <translation>Imprimer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="266"/>
        <source>Generar Arbol Binario</source>
        <translation>Générer un arbre binaire</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="275"/>
        <source>Deshacer</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="284"/>
        <source>Rehacer</source>
        <translation>Refaire</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="293"/>
        <source>Información</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="302"/>
        <source>Ingresar</source>
        <translation>Enterokay</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="28"/>
        <location filename="mainwindow.cpp" line="132"/>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Apellidos</source>
        <translation>Noms de famille</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="29"/>
        <location filename="mainwindow.cpp" line="133"/>
        <location filename="mainwindow.cpp" line="140"/>
        <source>Nombres</source>
        <translation>Noms</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="30"/>
        <location filename="mainwindow.cpp" line="134"/>
        <location filename="mainwindow.cpp" line="141"/>
        <source>Nota Final</source>
        <translation>Qualification finale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="50"/>
        <source> Aprobado</source>
        <translation> Approuvé</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="55"/>
        <source> Reprobado</source>
        <translation> Réprouver</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="66"/>
        <source>Notas</source>
        <translation>Évaluations</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="290"/>
        <location filename="mainwindow.cpp" line="297"/>
        <source>Imagen(*.png)</source>
        <translation>Imagen(*.png)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="85"/>
        <source>Guardado</source>
        <translation>Enregistré</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="85"/>
        <source>Archivo almacenada </source>
        <translation>Fichier stocké </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="300"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="300"/>
        <source>No pudo guaradar</source>
        <translation>Impossible d&apos;enregistrer</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="94"/>
        <location filename="mainwindow.cpp" line="262"/>
        <source>CSV File (*.csv)</source>
        <translation>CSV File (*.csv)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="152"/>
        <location filename="mainwindow.cpp" line="165"/>
        <location filename="mainwindow.cpp" line="186"/>
        <source>Promedio</source>
        <translation>Moyenne</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="175"/>
        <source>Error ingreso de notas</source>
        <translation>Erreur, entrée de note</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="175"/>
        <source>Ingreso de caracter no valido, se dejo una celda vacia o un numero mayor a 50. Se ingresara un 0.</source>
        <translation>Entrée de caractères non valide, il reste une cellule vide ou un nombre supérieur à 50. Un 0 sera entré.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="182"/>
        <source>Error suma de notas</source>
        <translation>Erreur, somme des notes</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="182"/>
        <source>La suma de notas es mayor a 100. Revise las notas ingresadas.</source>
        <translation>&quot;La somme des notes est supérieure à 100. Vérifiez les notes saisies.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="187"/>
        <source>General</source>
        <translation>générale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="290"/>
        <location filename="mainwindow.cpp" line="297"/>
        <source>Guardar Imagen</source>
        <translation>Sauvegarder image</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="303"/>
        <source>Reporte Completo de Notas</source>
        <translation>Bulletin scolaire</translation>
    </message>
</context>
<context>
    <name>NewTableDialog</name>
    <message>
        <location filename="newtabledialog.ui" line="14"/>
        <source>Nueva Tabla</source>
        <translation>Nouvelle table</translation>
    </message>
    <message>
        <location filename="newtabledialog.ui" line="53"/>
        <source>Número de Estudiantes</source>
        <translation>Nombre d&apos;étudiants</translation>
    </message>
    <message>
        <location filename="newtabledialog.ui" line="69"/>
        <source>Número de Notas</source>
        <translation>Nombre d&apos;évaluations</translation>
    </message>
</context>
<context>
    <name>TreeRec</name>
    <message>
        <location filename="treerec.ui" line="14"/>
        <location filename="treerec.ui" line="34"/>
        <source>Información</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="49"/>
        <source>Número de Estudiantes:</source>
        <translation>Nombre de notes:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="75"/>
        <source>Fecha:</source>
        <translation>Date:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="101"/>
        <source>Título:</source>
        <translation>Titre:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="123"/>
        <source>Número de Notas:</source>
        <translation>Nombre d&apos;évaluations:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="149"/>
        <source>Hora:</source>
        <translation>Heure:</translation>
    </message>
</context>
</TS>
