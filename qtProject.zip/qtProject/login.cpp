#include "login.h"
#include "ui_login.h"
#include <QMessageBox>

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
}

Login::~Login()
{
    delete ui;
}

bool Login::validation()
{
    QString email = ui->txt_email->text();
    QString password = ui->txt_password->text();

    for (int i = 0; i < emails.count(); i++) {
        if(email == emails.at(i) && password == passwords.at(i)){
            QMessageBox::information(this, tr("Inicio de sesion"), tr("Se ha iniciado correctamente sesion"));
            emailVal = email;
            return true;
        }else{
            QMessageBox::information(this, tr("Inicio de sesion"), tr("Usuario y contraseña invalido"));
            return false;
        }
    }
}

QString Login::getEmail()
{
    return emailVal;
}

void Login::on_buttonBox_accepted()
{
    validation();
    accepted();
}

void Login::on_buttonBox_rejected()
{
    rejected();
}
