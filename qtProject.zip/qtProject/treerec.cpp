#include "treerec.h"
#include "ui_treerec.h"
#include <QDateTime>

TreeRec::TreeRec(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TreeRec)
{
    ui->setupUi(this);
}

TreeRec::~TreeRec()
{
    delete ui;
}

void TreeRec::setData(QString _title, int _num_Act, int _num_Std)
{
    title = _title;
    num_Act = _num_Act;
    num_Std = _num_Std;
    ui->txt_Title->setText(title);
    ui->txt_Date->setText(QDateTime::currentDateTime().toString());
    ui->txt_Time->setText(QTime::currentTime().toString());
    ui->txt_NumAct->setText(QString::number(num_Act));
    ui->txt_NumStd->setText(QString::number(num_Std));
}

QString TreeRec::getTitle()
{
    title = ui->txt_Title->text();
    return title;
}

void TreeRec::on_buttonBox_accepted()
{
    getTitle();
    accept();
}

void TreeRec::on_buttonBox_rejected()
{
    reject();
}
