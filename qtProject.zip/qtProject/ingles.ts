<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="es_419">
<context>
    <name>Login</name>
    <message>
        <location filename="login.ui" line="14"/>
        <source>Ingresar</source>
        <translation>Entry</translation>
    </message>
    <message>
        <location filename="login.ui" line="46"/>
        <source>Contraseña</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="login.ui" line="77"/>
        <source>Correo Institucional</source>
        <translation>Institutional mail</translation>
    </message>
    <message>
        <location filename="login.ui" line="98"/>
        <source>Iniciar Sesión</source>
        <translation>Log In</translation>
    </message>
    <message>
        <location filename="login.cpp" line="24"/>
        <location filename="login.cpp" line="28"/>
        <source>Inicio de sesion</source>
        <translation>Login</translation>
    </message>
    <message>
        <location filename="login.cpp" line="24"/>
        <source>Se ha iniciado correctamente sesion</source>
        <translation>Session has been successfully started</translation>
    </message>
    <message>
        <location filename="login.cpp" line="28"/>
        <source>Usuario y contraseña invalido</source>
        <translation>Invalid username and password</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="32"/>
        <source>Qt Project</source>
        <translation>Qt Project</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>Archivo</source>
        <translation>Archive</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="89"/>
        <source>Herramientas</source>
        <translation>Tools</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="107"/>
        <source>Editar</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="114"/>
        <source>Cuenta</source>
        <translation>Account</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="126"/>
        <source>toolBar</source>
        <translation>ToolBar</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="144"/>
        <source>toolBar_2</source>
        <translation>ToolBar_2</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="167"/>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="94"/>
        <source>Guardar</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="176"/>
        <source>Nuevo Tabla</source>
        <translation>New Table</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="185"/>
        <location filename="mainwindow.cpp" line="262"/>
        <source>Abrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="194"/>
        <source>Generar Gráfica</source>
        <translation>Generate chart</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="203"/>
        <source>Agregar Actividad</source>
        <translation>Add Activity</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>Quitar Actividad</source>
        <translation>Remove Activity</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="221"/>
        <source>Agregar Estudiante</source>
        <translation>Add Student</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="230"/>
        <source>Quitar Estudiante</source>
        <translation>Remove student</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="239"/>
        <source>Calcular Promedio</source>
        <translation>Calculate average</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="248"/>
        <source>Guardar Gráfica</source>
        <translation>Save chart</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="257"/>
        <source>Imprimir</source>
        <translation>To print</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="266"/>
        <source>Generar Arbol Binario</source>
        <translation>Generate Binary Tree</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="275"/>
        <source>Deshacer</source>
        <translation>Undo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="284"/>
        <source>Rehacer</source>
        <translation>Redo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="293"/>
        <source>Información</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="302"/>
        <source>Ingresar</source>
        <translation>Enterokay</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="28"/>
        <location filename="mainwindow.cpp" line="132"/>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Apellidos</source>
        <translation>Last Names</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="29"/>
        <location filename="mainwindow.cpp" line="133"/>
        <location filename="mainwindow.cpp" line="140"/>
        <source>Nombres</source>
        <translation>Names</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="30"/>
        <location filename="mainwindow.cpp" line="134"/>
        <location filename="mainwindow.cpp" line="141"/>
        <source>Nota Final</source>
        <translation>Final score</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="50"/>
        <source> Aprobado</source>
        <translation> Approved</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="55"/>
        <source> Reprobado</source>
        <translation> Reprobate</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="66"/>
        <source>Notas</source>
        <translation>Scores</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="290"/>
        <location filename="mainwindow.cpp" line="297"/>
        <source>Imagen(*.png)</source>
        <translation>Image(*.png)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="85"/>
        <source>Guardado</source>
        <translation>Saved</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="85"/>
        <source>Archivo almacenada </source>
        <translation>Stored file </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="300"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="300"/>
        <source>No pudo guaradar</source>
        <translation>Can&apos;t save</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="94"/>
        <location filename="mainwindow.cpp" line="262"/>
        <source>CSV File (*.csv)</source>
        <translation>CSV File (*.csv)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="152"/>
        <location filename="mainwindow.cpp" line="165"/>
        <location filename="mainwindow.cpp" line="186"/>
        <source>Promedio</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="175"/>
        <source>Error ingreso de notas</source>
        <translation>Error, note entry</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="175"/>
        <source>Ingreso de caracter no valido, se dejo una celda vacia o un numero mayor a 50. Se ingresara un 0.</source>
        <translation>Invalid character entry, an empty cell or a number greater than 50 was left. A 0 will be entered.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="182"/>
        <source>Error suma de notas</source>
        <translation>Error, sum of notes</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="182"/>
        <source>La suma de notas es mayor a 100. Revise las notas ingresadas.</source>
        <translation>&quot;The sum of notes is greater than 100. Check the notes entered.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="187"/>
        <source>General</source>
        <translation>average</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="290"/>
        <location filename="mainwindow.cpp" line="297"/>
        <source>Guardar Imagen</source>
        <translation>Save Image</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="303"/>
        <source>Reporte Completo de Notas</source>
        <translation>Report card</translation>
    </message>
</context>
<context>
    <name>NewTableDialog</name>
    <message>
        <location filename="newtabledialog.ui" line="14"/>
        <source>Nueva Tabla</source>
        <translation>New Table</translation>
    </message>
    <message>
        <location filename="newtabledialog.ui" line="53"/>
        <source>Número de Estudiantes</source>
        <translation>Number of students</translation>
    </message>
    <message>
        <location filename="newtabledialog.ui" line="69"/>
        <source>Número de Notas</source>
        <translation>Number of grades</translation>
    </message>
</context>
<context>
    <name>TreeRec</name>
    <message>
        <location filename="treerec.ui" line="14"/>
        <location filename="treerec.ui" line="34"/>
        <source>Información</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="49"/>
        <source>Número de Estudiantes:</source>
        <translation>Number of students:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="75"/>
        <source>Fecha:</source>
        <translation>Date:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="101"/>
        <source>Título:</source>
        <translation>Title:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="123"/>
        <source>Número de Notas:</source>
        <translation>Number of grades:</translation>
    </message>
    <message>
        <location filename="treerec.ui" line="149"/>
        <source>Hora:</source>
        <translation>Hour:</translation>
    </message>
</context>
</TS>
